import express from 'express';
import mongoose from 'mongoose';
import path from "path";
import ejsLayouts from 'express-ejs-layouts';
import session from 'express-session';
import passport from 'passport';
import flash from "connect-flash"
import { connectUsingMongoose } from './src/config/mongoos.js';
import router from './src/routes/routes.js';
import passportlocal from "./src/config/passport.js";


const app = express();
const PORT = process.env.PORT || 3300;

app.set('view engine', 'ejs');
app.set('views',path.join(path.resolve(),'src','views'))
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));
app.use(ejsLayouts)
app.use(session({ secret: 'your-secret-key', resave: true, saveUninitialized: true }));
app.use(passport.initialize());
app.use(passport.session());
app.use(passport.setAuthenticatedUser);
// app.use(function() {
//   app.use(express.cookieParser('keyboard cat'));
//   app.use(express.session({ cookie: { maxAge: 60000 }}));
//   app.use(flash());
// });
app.use(flash());
app.use((req, res, next) => {
  res.locals.messages = req.flash();
  next();
});

// app.use((req, res, next) => {
//   console.log('Middleware setting flash messages executed.');
//   // res.locals.messages = req.flash();
//   console.log('Flash Messages:', res.locals.messages);
//   next();
// });

app.use('/',router);




app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
    connectUsingMongoose();
  });